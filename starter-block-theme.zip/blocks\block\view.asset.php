<?php return array('dependencies' => array(), 'version' => '0977beaa9f47c84daabb');
