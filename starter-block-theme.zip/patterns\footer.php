<?php

/**
 * Title: footer
 * Slug: starter-block/footer
 * Categories: Footer
 * Inserter: no
 */
?>
<!-- wp:paragraph -->
<p><?php esc_html_e('Powered by Raphael Borges', 'starter-block'); ?></p>
<!-- /wp:paragraph -->